package com.example.condencedgeek.Model;

import java.util.HashSet;
import java.util.Set;

public class Order {

    public static Set<Integer> ItemsId = new HashSet<>();
}
